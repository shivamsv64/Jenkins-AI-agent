# Jenkins AI Agent

AI-powered Jenkins failure diagnostics using Amazon Bedrock (Nova Pro) + Google Chat webhooks with Approve/Reject actions.

## Architecture

```
jenkins-ai-agent/
├── config/
│   └── config.yaml          # All config (no secrets hardcoded)
├── src/
│   ├── jenkins_client.py    # Jenkins REST API interactions
│   ├── bedrock_client.py    # Amazon Bedrock / Nova Pro LLM
│   ├── gchat_client.py      # Google Chat webhook + card builder
│   ├── remediation.py       # Remediation action executor
│   └── agent.py             # Core orchestration logic
├── scripts/
│   └── setup_ssm_params.sh  # One-time secret setup in AWS SSM
├── webhook_server.py        # Flask server for Approve/Reject callbacks
├── main.py                  # CLI entrypoint
├── requirements.txt
└── .env.example             # Template (never commit real .env)
```

## Secret Management

All secrets are stored in **AWS SSM Parameter Store** (SecureString).
No passwords, tokens, or keys are hardcoded anywhere.

Secrets stored in SSM:
- `/jenkins-ai-agent/jenkins/url`
- `/jenkins-ai-agent/jenkins/username`
- `/jenkins-ai-agent/jenkins/api_token`
- `/jenkins-ai-agent/gchat/webhook_url`

AWS credentials are sourced from your local `~/.aws/credentials` (already configured via `aws configure`).

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Store secrets in SSM (one-time setup)
bash scripts/setup_ssm_params.sh

# 3. Edit config/config.yaml (non-secret settings only)

# 4. Run agent once
python main.py --mode once

# 5. Run agent as daemon (polls every N seconds)
python main.py --mode daemon

# 6. Start webhook server for Approve/Reject callbacks (separate terminal)
python webhook_server.py
```

## Modes

| Mode | Description |
|------|-------------|
| `once` | Check all jobs once, send alerts, exit |
| `daemon` | Poll continuously on configured interval |
| `job <name>` | Analyze a specific job by name |

## Google Chat Flow

1. Agent detects failed Jenkins build
2. Nova Pro analyzes console log → root cause + fix steps
3. Card v2 message sent to Google Chat with:
   - Job name, build number, duration, branch
   - AI-generated root cause summary
   - Suggested fix steps
   - **Approve** button → triggers remediation
   - **Reject** button → dismisses alert
4. User clicks Approve → webhook server receives callback → executes fix
