# src/agent.py
"""
Core Jenkins AI Agent orchestrator.
Wires together: JenkinsClient → BedrockClient → GChatClient.
Tracks already-alerted builds to avoid duplicate notifications.
"""

from __future__ import annotations
import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

from src.jenkins_client import JenkinsClient, BuildInfo
from src.bedrock_client import BedrockClient
from src.gchat_client import GChatClient

logger = logging.getLogger(__name__)

# File used to track which builds have already been alerted
ALERTED_BUILDS_FILE = Path("logs/.alerted_builds.json")


class JenkinsAIAgent:
    """
    Orchestrates failure detection → LLM analysis → Google Chat notification.
    """

    def __init__(
        self,
        jenkins: JenkinsClient,
        bedrock: BedrockClient,
        gchat: GChatClient,
        cfg: dict,
    ):
        self.jenkins = jenkins
        self.bedrock = bedrock
        self.gchat = gchat
        self.cfg = cfg
        self._alerted: set[str] = self._load_alerted()

    # ──────────────────────────────────────────────
    # Public entrypoints
    # ──────────────────────────────────────────────

    def run_once(self) -> dict:
        """Scan all configured jobs once. Returns summary dict."""
        agent_cfg = self.cfg.get("agent", {})
        filter_names = agent_cfg.get("job_filter", [])
        ignore_names = agent_cfg.get("ignore_jobs", [])
        lookback = agent_cfg.get("lookback_builds", 3)
        max_log_chars = agent_cfg.get("max_log_chars", 8000)

        jobs = self.jenkins.list_jobs(
            filter_names=filter_names,
            ignore_names=ignore_names,
        )
        logger.info("Scanning %d jobs...", len(jobs))

        summary = {"jobs_scanned": 0, "failures_found": 0, "alerts_sent": 0}
        for job_name in jobs:
            summary["jobs_scanned"] += 1
            try:
                failed = self.jenkins.get_failed_builds(
                    job_name, lookback=lookback, max_log_chars=max_log_chars
                )
                for build in failed:
                    summary["failures_found"] += 1
                    if self._process_build(build):
                        summary["alerts_sent"] += 1
            except Exception as exc:
                logger.error("Error processing job '%s': %s", job_name, exc)

        logger.info("Run complete — %s", summary)
        return summary

    def run_daemon(self, interval: Optional[int] = None):
        """Poll Jenkins in a loop."""
        if interval is None:
            interval = self.cfg.get("agent", {}).get("poll_interval_seconds", 60)
        logger.info("Daemon mode — polling every %ds", interval)
        while True:
            try:
                self.run_once()
            except Exception as exc:
                logger.error("Unexpected error in daemon loop: %s", exc)
            logger.info("Sleeping %ds...", interval)
            time.sleep(interval)

    def analyze_job(self, job_name: str) -> dict:
        """Analyze a single job by name and return results."""
        agent_cfg = self.cfg.get("agent", {})
        lookback = agent_cfg.get("lookback_builds", 3)
        max_log_chars = agent_cfg.get("max_log_chars", 8000)

        failed = self.jenkins.get_failed_builds(
            job_name, lookback=lookback, max_log_chars=max_log_chars
        )
        results = []
        for build in failed:
            sent = self._process_build(build)
            results.append({
                "build_number": build.build_number,
                "result": build.result,
                "alert_sent": sent,
            })
        return {"job": job_name, "builds": results}

    # ──────────────────────────────────────────────
    # Internal
    # ──────────────────────────────────────────────

    def _process_build(self, build: BuildInfo) -> bool:
        """Analyze a failed build and send a GChat alert if not already sent."""
        build_key = f"{build.job_name}#{build.build_number}"
        if build_key in self._alerted:
            logger.debug("Skipping already-alerted build: %s", build_key)
            return False

        logger.info(
            "Analyzing %s #%d (%s)...", build.job_name, build.build_number, build.result
        )

        diagnostic = self.bedrock.analyze_failure(build)
        logger.info(
            "Diagnosis: %s | Confidence: %s | Action: %s",
            diagnostic.error_type, diagnostic.confidence, diagnostic.suggested_action,
        )

        sent = self.gchat.send_failure_alert(build, diagnostic)
        if sent:
            self._mark_alerted(build_key)
            logger.info("Alert sent for %s", build_key)
        else:
            logger.warning("Failed to send GChat alert for %s", build_key)

        return sent

    # ──────────────────────────────────────────────
    # Alerted-build persistence (avoids duplicate alerts across runs)
    # ──────────────────────────────────────────────

    def _load_alerted(self) -> set[str]:
        if ALERTED_BUILDS_FILE.exists():
            try:
                data = json.loads(ALERTED_BUILDS_FILE.read_text())
                return set(data.get("alerted", []))
            except Exception:
                pass
        return set()

    def _mark_alerted(self, build_key: str):
        self._alerted.add(build_key)
        # Keep only last 500 to prevent unbounded growth
        trimmed = list(self._alerted)[-500:]
        ALERTED_BUILDS_FILE.parent.mkdir(parents=True, exist_ok=True)
        ALERTED_BUILDS_FILE.write_text(
            json.dumps({"alerted": trimmed}, indent=2)
        )
